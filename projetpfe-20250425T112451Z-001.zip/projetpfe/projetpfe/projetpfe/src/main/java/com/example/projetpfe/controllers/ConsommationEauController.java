package com.example.projetpfe.controllers;
import com.example.projetpfe.services.ConsommationEauService;
import com.example.projetpfe.entity.ConsommationEau;
import com.example.projetpfe.entity.User;

import com.example.projetpfe.services.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/consommation-eau")
public class ConsommationEauController {

    private final ConsommationEauService service;
    private final UserService userService;

    public ConsommationEauController(ConsommationEauService service, UserService userService) {
        this.service = service;
        this.userService = userService;
    }

    @PostMapping
    public ConsommationEau ajouter(@RequestBody ConsommationEau ce) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        System.out.println("Authenticated user: " + auth.getName());
        String email = auth.getName();
        User user = userService.findByEmail(email);
        System.out.println("Found user: " + (user != null ? user.getId() : "null"));
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        ce.setUser(user);
        System.out.println("Saving consumption: " + ce);
        return service.save(ce);
    }

    @PutMapping("/{id}")
    public ConsommationEau modifier(@PathVariable Long id, @RequestBody ConsommationEau updatedCe) {
        ConsommationEau existing = service.findById(id);
        if (existing == null) {
            throw new RuntimeException("Consommation d'eau non trouvée avec ID: " + id);
        }
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User user = userService.findByEmail(email);
        if (user == null || !existing.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Unauthorized to modify this consumption");
        }
        existing.setValue(updatedCe.getValue());
        existing.setPrix(updatedCe.getPrix());
        existing.setCategory(updatedCe.getCategory());
        existing.setDate(updatedCe.getDate());
        existing.setNotes(updatedCe.getNotes());
        return service.save(existing);
    }

    @DeleteMapping("/{id}")
    public void supprimer(@PathVariable Long id) {
        ConsommationEau existing = service.findById(id);
        if (existing == null) {
            throw new RuntimeException("Consommation d'eau non trouvée avec ID: " + id);
        }
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User user = userService.findByEmail(email);
        if (user == null || !existing.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Unauthorized to delete this consumption");
        }
        service.delete(id);
    }

    @GetMapping
    public List<ConsommationEau> getAll() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User user = userService.findByEmail(email);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        return service.findByUserId(user.getId());
    }

    @GetMapping("/{id}")
    public ConsommationEau getById(@PathVariable Long id) {
        ConsommationEau ce = service.findById(id);
        if (ce == null) {
            throw new RuntimeException("Consommation d'eau non trouvée avec ID: " + id);
        }
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User user = userService.findByEmail(email);
        if (user == null || !ce.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Unauthorized to view this consumption");
        }
        return ce;
    }

    @GetMapping("/stats")
    public Map<String, Object> getStats(
            @RequestParam String period,
            @RequestParam String startDate,
            @RequestParam String endDate) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User user = userService.findByEmail(email);
        if (user == null) {
            throw new RuntimeException("User not found");
        }

        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);

        Map<String, Object> response = new HashMap<>();
        response.put("consumptionByPeriod", service.getConsumptionByPeriod(user.getId(), start, end, period));


        response.put("priceByPeriod", service.getPriceByPeriod(user.getId(), start, end, period));

        
        response.put("categoryBreakdown", service.getCategoryBreakdown(user.getId(), start, end));
        response.put("stats", service.getStats(user.getId(), start, end));
        System.out.println("Stats response: " + response); // Debug log
        return response;
    }
}