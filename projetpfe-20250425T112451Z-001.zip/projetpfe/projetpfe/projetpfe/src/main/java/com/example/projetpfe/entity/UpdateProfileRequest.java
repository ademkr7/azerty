package com.example.projetpfe.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateProfileRequest {

    private String userName;
    private String email;
    private String address;
    private long phoneNumber;
    private long nombreOccupant;
    private String typeLogement;
    private String password;

}
