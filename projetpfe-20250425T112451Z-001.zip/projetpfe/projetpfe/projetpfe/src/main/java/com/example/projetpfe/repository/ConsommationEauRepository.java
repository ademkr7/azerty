package com.example.projetpfe.repository;

import com.example.projetpfe.entity.ConsommationEau;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface ConsommationEauRepository extends JpaRepository<ConsommationEau, Long> {
    List<ConsommationEau> findByUserId(Long userId);
    List<ConsommationEau> findByUserIdAndDateBetween(Long userId, LocalDate startDate, LocalDate endDate);

    @Query("SELECT ce.category, SUM(ce.value) as totalValue " +
            "FROM ConsommationEau ce " +
            "WHERE ce.user.id = :userId AND ce.date BETWEEN :startDate AND :endDate " +
            "GROUP BY ce.category")
    List<Object[]> findCategoryBreakdownByUserIdAndDateBetween(Long userId, LocalDate startDate, LocalDate endDate);

    @Query("SELECT ce.date, SUM(ce.value) as totalValue " +
            "FROM ConsommationEau ce " +
            "WHERE ce.user.id = :userId AND ce.date BETWEEN :startDate AND :endDate " +
            "GROUP BY ce.date")
    List<Object[]> findConsumptionByPeriod(Long userId, LocalDate startDate, LocalDate endDate);


    // New query for price by period
    @Query("SELECT ce.date, SUM(ce.prix) as totalPrix " +
            "FROM ConsommationEau ce " +
            "WHERE ce.user.id = :userId AND ce.date BETWEEN :startDate AND :endDate " +
            "GROUP BY ce.date")
    List<Object[]> findPriceByPeriod(Long userId, LocalDate startDate, LocalDate endDate);
}
