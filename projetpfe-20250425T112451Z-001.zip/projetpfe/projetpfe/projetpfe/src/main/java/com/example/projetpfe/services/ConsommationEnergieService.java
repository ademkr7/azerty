package com.example.projetpfe.services;

import com.example.projetpfe.entity.ConsommationEnergie;
import com.example.projetpfe.repository.ConsommationEnergieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.mail.MessagingException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ConsommationEnergieService {

    private final ConsommationEnergieRepository repository;
    private final EmailService emailService;
    private final double ENERGY_THRESHOLD = 10; // Example threshold in kWh per day

    @Autowired
    public ConsommationEnergieService(ConsommationEnergieRepository repository, EmailService emailService) {
        this.repository = repository;
        this.emailService = emailService;
    }

    public ConsommationEnergie save(ConsommationEnergie ce) {
        ConsommationEnergie saved = repository.save(ce);
        // Check for overconsumption
        double dailyValue = ce.getValue(); // Assuming value is for the day
        if (dailyValue > ENERGY_THRESHOLD && ce.getUser() != null) {
            sendNotifications(ce.getUser().getEmail(), ce.getUser().getUsername(), "énergie", dailyValue, ENERGY_THRESHOLD);
        }
        return saved;
    }

    private void sendNotifications(String email, String userName, String type, double value, double threshold) {
        try {
            emailService.sendOverconsumptionAlert(email, userName, type, value, threshold);
            emailService.sendSavingTips(email, userName, type);
        } catch (MessagingException e) {
            System.err.println("Failed to send overconsumption alert: " + e.getMessage());
        }
    }

    // Other existing methods remain unchanged
    public ConsommationEnergie findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public List<ConsommationEnergie> findAll() {
        return repository.findAll();
    }

    public List<ConsommationEnergie> findByUserId(Long userId) {
        return repository.findByUserId(userId);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public Map<String, Double> getPriceByPeriod(Long userId, LocalDate startDate, LocalDate endDate, String period) {
        List<Object[]> results = repository.findPriceByPeriod(userId, startDate, endDate);
        Map<String, Double> price = new HashMap<>();

        LocalDate currentDate = startDate;
        while (!currentDate.isAfter(endDate)) {
            String key;
            if (period.equals("weekly")) {
                LocalDate startOfWeek = currentDate.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY));
                key = startOfWeek.toString();
            } else if (period.equals("monthly")) {
                key = currentDate.getYear() + "-" + String.format("%02d", currentDate.getMonthValue());
            } else {
                key = currentDate.toString();
            }
            price.putIfAbsent(key, 0.0);
            currentDate = currentDate.plusDays(1);
        }

        for (Object[] result : results) {
            LocalDate date = (LocalDate) result[0];
            Double value = ((Number) result[1]).doubleValue();
            String key;

            if (period.equals("weekly")) {
                LocalDate startOfWeek = date.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY));
                key = startOfWeek.toString();
            } else if (period.equals("monthly")) {
                key = date.getYear() + "-" + String.format("%02d", date.getMonthValue());
            } else {
                key = date.toString();
            }

            price.merge(key, value, Double::sum);
        }

        return price;
    }

    public List<ConsommationEnergie> findByUserIdAndDateRange(Long userId, LocalDate startDate, LocalDate endDate) {
        return repository.findByUserIdAndDateBetween(userId, startDate, endDate);
    }

    public Map<String, Double> getCategoryBreakdown(Long userId, LocalDate startDate, LocalDate endDate) {
        List<Object[]> results = repository.findCategoryBreakdownByUserIdAndDateBetween(userId, startDate, endDate);
        Map<String, Double> breakdown = new HashMap<>();
        double total = 0;

        for (Object[] result : results) {
            String category = (String) result[0];
            Double value = ((Number) result[1]).doubleValue();
            total += value;
            breakdown.put(category, value);
        }

        Map<String, Double> percentageBreakdown = new HashMap<>();
        for (Map.Entry<String, Double> entry : breakdown.entrySet()) {
            percentageBreakdown.put(entry.getKey(), total > 0 ? (entry.getValue() / total) * 100 : 0);
        }
        return percentageBreakdown;
    }

    public Map<String, Double> getConsumptionByPeriod(Long userId, LocalDate startDate, LocalDate endDate, String period) {
        List<Object[]> results = repository.findConsumptionByPeriod(userId, startDate, endDate);
        Map<String, Double> consumption = new HashMap<>();

        LocalDate currentDate = startDate;
        while (!currentDate.isAfter(endDate)) {
            String key;
            if (period.equals("weekly")) {
                LocalDate startOfWeek = currentDate.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY));
                key = startOfWeek.toString();
            } else if (period.equals("monthly")) {
                key = currentDate.getYear() + "-" + String.format("%02d", currentDate.getMonthValue());
            } else {
                key = currentDate.toString();
            }
            consumption.putIfAbsent(key, 0.0);
            currentDate = currentDate.plusDays(1);
        }

        for (Object[] result : results) {
            LocalDate date = (LocalDate) result[0];
            Double value = ((Number) result[1]).doubleValue();
            String key;

            if (period.equals("weekly")) {
                LocalDate startOfWeek = date.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY));
                key = startOfWeek.toString();
            } else if (period.equals("monthly")) {
                key = date.getYear() + "-" + String.format("%02d", date.getMonthValue());
            } else {
                key = date.toString();
            }

            consumption.merge(key, value, Double::sum);
        }

        return consumption;
    }

    public Map<String, Double> getStats(Long userId, LocalDate startDate, LocalDate endDate) {
        List<ConsommationEnergie> data = repository.findByUserIdAndDateBetween(userId, startDate, endDate);
        double total = data.stream().mapToDouble(ConsommationEnergie::getValue).sum();
        long days = ChronoUnit.DAYS.between(startDate, endDate) + 1;
        double average = days > 0 ? total / days : 0;

        Map<String, Double> stats = new HashMap<>();
        stats.put("total", total / 1000); // Convert to appropriate unit
        stats.put("average", average);
        return stats;
    }
}