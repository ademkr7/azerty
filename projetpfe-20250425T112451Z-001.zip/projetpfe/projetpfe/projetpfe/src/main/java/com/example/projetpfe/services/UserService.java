package com.example.projetpfe.services;

import com.example.projetpfe.entity.User;
import com.example.projetpfe.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    private final String uploadDir = "./uploads/user/";

    @Autowired
    private PasswordEncoder passwordEncoder;



    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User addUser(User user) {
        User savedUser = userRepository.save(user);

        return savedUser;
    }

    public void deleteUser(Long id) {
        User user = getUserById(id);
        if (user.getProfileImage() != null) {
            new File("." + user.getProfileImage()).delete();
        }
        userRepository.deleteById(id);
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }

    public User updateUser(Long userId, User updatedUserInfo) {
        Optional<User> existingUserOptional = userRepository.findById(userId);

        if (existingUserOptional.isPresent()) {
            User existingUser = existingUserOptional.get();

            if (updatedUserInfo.getUsername() != null) {
                existingUser.setUserName(updatedUserInfo.getUsername());
            }

            if (updatedUserInfo.getEmail() != null) {
                existingUser.setEmail(updatedUserInfo.getEmail());
            }

            if (updatedUserInfo.getPassword() != null && !updatedUserInfo.getPassword().isEmpty()) {
                existingUser.setPassword(passwordEncoder.encode(updatedUserInfo.getPassword()));
            }

            if (updatedUserInfo.getPhoneNumber() != null) {
                existingUser.setPhoneNumber(updatedUserInfo.getPhoneNumber());
            }

            if (updatedUserInfo.getAddress() != null) {
                existingUser.setAddress(updatedUserInfo.getAddress());
            }

            if (updatedUserInfo.getNombreOccupant() != null) {
                existingUser.setNombreOccupant(updatedUserInfo.getNombreOccupant());
            }

            if (updatedUserInfo.getTypeLogement() != null) {
                existingUser.setTypeLogement(updatedUserInfo.getTypeLogement());
            }

            if (updatedUserInfo.getRole() != null) {
                existingUser.setRole(updatedUserInfo.getRole());
            }

            return userRepository.save(existingUser);
        } else {
            throw new RuntimeException("Utilisateur avec ID " + userId + " non trouvé");
        }
    }

    public User uploadProfileImage(String email, MultipartFile file) throws IOException {
        User user = findByEmail(email);
        if (user == null) {
            throw new RuntimeException("User not found");
        }

        if (!file.getContentType().startsWith("image/")) {
            throw new IllegalArgumentException("Only image files are allowed");
        }

        File directory = new File(uploadDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = email.replace("@", "_") + "_" + System.currentTimeMillis() + "_" + file.getOriginalFilename();
        Path filePath = Paths.get(uploadDir, fileName);

        Files.write(filePath, file.getBytes());

        user.setProfileImage("/uploads/user/" + fileName);
        return userRepository.save(user);
    }




}