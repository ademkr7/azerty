import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddEnergiePage } from './add-energie.page';

describe('AddEnergiePage', () => {
  let component: AddEnergiePage;
  let fixture: ComponentFixture<AddEnergiePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEnergiePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
