import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastController, AlertController } from '@ionic/angular';
import { formatDate } from '@angular/common';
import { IonHeader, IonButtons, IonTitle, IonBackButton, IonToolbar, IonContent, IonIcon, IonItem, IonLabel, IonText, IonButton, IonSpinner, IonCard, IonCardContent, IonInput, IonTextarea, IonDatetime } from "@ionic/angular/standalone";
import { addIcons } from 'ionicons';
import { flashOutline } from 'ionicons/icons';
import { bulbOutline } from 'ionicons/icons';
import { flameOutline } from 'ionicons/icons';
import { snowOutline } from 'ionicons/icons';
import { addCircleOutline } from 'ionicons/icons';
import { IonicModule } from '@ionic/angular';
import { HttpClientModule } from '@angular/common/http';
import { ConsommationEnergieService,ConsommationEnergie } from '../services/ConsommationEnergieService';
import { AuthService } from '../services/auth.services';
import { JwtHelperService } from '@auth0/angular-jwt';
import { SettingsService } from '../services/SettingsService';

@Component({
  selector: 'app-add-energie',
  templateUrl: './add-energie.page.html',
  styleUrls: ['./add-energie.page.scss'],
  standalone: true,
  imports: [
    IonicModule,
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [AuthService,ConsommationEnergieService,SettingsService ]
})
export class AddEnergiePage implements OnInit {
  consomationForm!: FormGroup;
  isSubmitting = false;
  currentDate = new Date();
  energyUnit: string = 'kWh'; // Default unit
  private jwtHelper: JwtHelperService = new JwtHelperService();

  energyCategories = [
    { name: 'Éclairage', icon: 'bulb-outline' },
    { name: 'Chauffage', icon: 'flame-outline' },
    { name: 'Appareils électriques', icon: 'flash-outline' },
    { name: 'Climatisation', icon: 'snow-outline' },
    { name: 'Autre', icon: 'add-circle-outline' }
  ];

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private toastController: ToastController,
    private alertController: AlertController,
    private consomationService: ConsommationEnergieService,
    private authService: AuthService,
    private settingsService: SettingsService
  ) {
    this.consomationForm = this.formBuilder.group({
      value: ['', [Validators.required, Validators.min(0.1)]],
      prix: ['', [Validators.required]],
      category: ['', Validators.required],
      date: [formatDate(this.currentDate, 'yyyy-MM-dd', 'en'), Validators.required],
      notes: ['']
    });

    addIcons({
      'flash-outline': flashOutline,
      'bulb-outline': bulbOutline,
      'flame-outline': flameOutline,
      'snow-outline': snowOutline,
      'add-circle-outline': addCircleOutline
    });
  }

  ngOnInit(): void {
    // Load energy unit from settings
    this.settingsService.getSettings().subscribe(settings => {
      this.energyUnit = settings.energyUnit || 'kWh';
    });
    console.log('AddEnergiePage initialisée');
  }

  get title() {
    return "Ajouter consommation d'énergie";
  }

  get unit() {
    return this.energyUnit === 'kWh' ? 'kWh' : 'W';
  }

  get categories() {
    return this.energyCategories;
  }

  selectCategory(category: string) {
    this.consomationForm.get('category')?.setValue(category);
  }

  submitForm() {
    if (this.consomationForm.valid) {
      this.isSubmitting = true;

      const token = this.authService.getToken();
      if (!token) {
        this.isSubmitting = false;
        this.presentToast('Aucun token trouvé. Veuillez vous connecter.', 'danger');
        this.router.navigate(['/loginpage']);
        return;
      }

      const decoded = this.jwtHelper.decodeToken(token);
      const currentTimestamp = Math.floor(Date.now() / 1000);
      const expTimestamp = decoded.exp;
      const isExpired = currentTimestamp > expTimestamp;

      if (isExpired || this.jwtHelper.isTokenExpired(token)) {
        this.isSubmitting = false;
        this.presentToast('Session expirée. Veuillez vous reconnecter.', 'danger');
        this.router.navigate(['/loginpage']);
        return;
      }

      const userId = this.authService.getCurrentUserId();
      if (!userId) {
        this.isSubmitting = false;
        this.presentToast('Impossible d\'identifier l\'utilisateur. Veuillez vous reconnecter.', 'danger');
        this.router.navigate(['/loginpage']);
        return;
      }

      // Convert value to kWh if unit is W
      const value = this.energyUnit === 'W' ? this.consomationForm.value.value / 1000 : this.consomationForm.value.value;

      const consommationData = {
        value: value,
        prix: this.consomationForm.value.prix,
        category: this.consomationForm.value.category,
        date: this.consomationForm.value.date,
        notes: this.consomationForm.value.notes,
        userId: userId
      };

      this.consomationService.addConsommationEnergie(consommationData)
        .subscribe({
          next: (response: ConsommationEnergie) => {
            this.isSubmitting = false;
            this.presentToast('Consommation d\'énergie enregistrée avec succès!', 'success');
            this.router.navigate(['/energie-dashboard-page']);
          },
          error: (error) => {
            this.isSubmitting = false;
            let errorMessage = 'Erreur lors de l\'enregistrement. Veuillez réessayer.';
            if (error.status === 403) {
              errorMessage = 'Accès refusé. Veuillez vous connecter à nouveau.';
              this.authService.logout();
              this.router.navigate(['/loginpage']);
            } else if (error.status === 0) {
              errorMessage = 'Erreur de connexion au serveur. Vérifiez votre réseau.';
            }
            this.presentToast(errorMessage, 'danger');
            console.error('Erreur:', error);
          }
        });
    } else {
      this.markFormGroupTouched(this.consomationForm);
      this.presentToast('Veuillez remplir tous les champs obligatoires.', 'warning');
    }
  }

  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: color,
      position: 'bottom'
    });
    await toast.present();
  }
  addwater() {
    this.router.navigate(['/add-water']);
  }
  addenergie() {
    this.router.navigate(['/add-energie']);
  }
}