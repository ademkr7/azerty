// import { NgModule } from '@angular/core';
// import { HTTP_INTERCEPTORS } from '@angular/common/http';
// import { AuthInterceptor } from './interceptors/auth.interceptor'; 
// import { HttpClientModule } from '@angular/common/http';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { IonicStorageModule } from '@ionic/storage-angular';
// import { AuthService } from './services/auth.services';

// @NgModule({
//   imports: [
//     HttpClientModule, 
//      // Module nécessaire pour les requêtes HTTP
//     FormsModule,
//     ReactiveFormsModule,
   
//     IonicStorageModule.forRoot()  // Stockage local pour Ionic
//   ],
//   providers: [
//     {
//       provide: HTTP_INTERCEPTORS,
//       useClass: AuthInterceptor, // Utilisation de l'AuthInterceptor pour ajouter le token
//       multi: true // Permet d'ajouter plusieurs interceptors si nécessaire
//     },
//     AuthService
//   ]
// })
// export class AppModule {}
import { NgModule } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './interceptors/auth.interceptor'; 
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicStorageModule } from '@ionic/storage-angular';
import { AuthService } from './services/auth.services';

@NgModule({
  imports: [
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    IonicStorageModule.forRoot(),
   
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    AuthService
  ]
})
export class AppModule {}


