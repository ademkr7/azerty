import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then((m) => m.HomePage),
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'loginpage',
    loadComponent: () => import('./loginpage/loginpage.page').then( m => m.LoginPage)
  },
  {
    path: 'registerpage',
    loadComponent: () => import('./registerpage/registerpage.page').then( m => m.RegisterPage)
  },
 
  {
    path: 'dashboard',
    loadComponent: () => import('./dashboard/dashboard.page').then( m => m.DashboardPage)
  },


  
  {
    path: 'add-water',
    loadComponent: () => import('./add-water/add-water.page').then( m => m.AddWaterPage)
  },
  {
    path: 'add-energie',
    loadComponent: () => import('./add-energie/add-energie.page').then( m => m.AddEnergiePage)
  },

  {
    path: 'settings-page',
    loadComponent: () => import('./settings-page/settings-page.page').then( m => m.SettingsPagePage)
  },

  {
    path: 'profile-page',
    loadComponent: () => import('./profile-page/profile-page.page').then( m => m.ProfilePagePage)
  },
  {
    path: 'water-dashboard-page',
    loadComponent: () => import('./water-dashboard-page/water-dashboard-page.page').then( m => m.WaterDashboardPagePage)
  },
  {
    path: 'energie-dashboard-page',
    loadComponent: () => import('./energie-dashboard-page/energie-dashboard-page.page').then( m => m.EnergieDashboardPagePage)
  },
  {
    path: 'historique-eau-page',
    loadComponent: () => import('./historique-eau-page/historique-eau-page.page').then( m => m.HistoriqueEauPagePage)
  },
  {
    path: 'historique-energie-page',
    loadComponent: () => import('./historique-energie-page/historique-energie-page.page').then( m => m.HistoriqueEnergiePagePage)
  },
 
 
 
 
  
  
  
 
 

 
  

 
]

