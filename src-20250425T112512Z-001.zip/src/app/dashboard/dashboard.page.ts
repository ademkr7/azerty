// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { IonSplitPane, IonMenu, IonMenuButton, IonContent, IonHeader, IonTitle, IonToolbar, IonCardContent, IonButton, IonButtons, IonCard, IonCardHeader, IonCardTitle, IonIcon, IonList, IonItem, IonLabel, IonApp, IonFooter, IonRouterOutlet, IonTabs, IonTabBar, IonTabButton, IonAvatar } from '@ionic/angular/standalone';
// import { NavController } from '@ionic/angular';
// import { waterOutline, flashOutline, addCircleOutline, timeOutline, settingsOutline, leafOutline, bulbOutline, sunnyOutline, barChartOutline, personOutline, logOutOutline, personCircleOutline } from 'ionicons/icons';
// import { addIcons } from 'ionicons';
// import { Router } from '@angular/router';
// import { HttpClient, HttpClientModule } from '@angular/common/http';
// import { AuthService } from '../services/auth.services';

// @Component({
//   selector: 'app-dashboard',
//   templateUrl: './dashboard.page.html',
//   styleUrls: ['./dashboard.page.scss'],
//   standalone: true,
//   imports: [
//     HttpClientModule,
//     IonAvatar,
//     IonRouterOutlet,
//     IonFooter,
//     IonApp,
//     IonMenu,
//     IonMenuButton,
//     IonLabel,
//     IonItem,
//     IonList,
//     IonIcon,
//     IonCardTitle,
//     IonCardHeader,
//     IonCard,
//     IonButtons,
//     IonCardContent,
//     IonContent,
//     IonHeader,
//     IonTitle,
//     IonToolbar,
//     CommonModule,
//     FormsModule,
//     IonTabs,
//     IonTabBar,
//     IonTabButton
//   ],
//   providers: [AuthService]
// })
// export class DashboardPage implements OnInit {
//   private apiUrl = 'http://localhost:8081/api/users';
//   user: any = null;

//   constructor(
//     private navCtrl: NavController,
//     private router: Router,
//     private authService: AuthService,
//     private http: HttpClient
//   ) {
//     addIcons({personCircleOutline,barChartOutline,waterOutline,flashOutline,settingsOutline,personOutline,logOutOutline,leafOutline,bulbOutline,sunnyOutline,addCircleOutline,timeOutline,'waterOutline':waterOutline,'bulbOutline':bulbOutline,'flashOutline':flashOutline,'addCircleOutline':addCircleOutline,'timeOutline':timeOutline,'settingsOutline':settingsOutline,'leafOutline':leafOutline,'barChartOutline':barChartOutline,'personOutline':personOutline,'logOutOutline':logOutOutline,'sunnyOutline':sunnyOutline,'personCircleOutline':personCircleOutline});
//   }

//   ngOnInit(): void {
//     console.log('Dashboard initialized');
//     this.loadUserProfile(); // Appeler la méthode pour charger le profil
//   }

//   loadUserProfile() {
//     const userId = this.authService.getCurrentUserId();
//     if (!userId || isNaN(userId)) {
//       console.error('Invalid user ID');
//       this.router.navigate(['/loginpage']);
//       return;
//     }

//     this.http.get(`${this.apiUrl}/profile/${userId}`).subscribe({
//       next: (response: any) => {
//         this.user = response;
//         if (this.user.profileImage) {
//           this.user.profileImage = `${this.apiUrl.replace('/api/users', '')}${this.user.profileImage}`;
//         }
//         console.log('User profile loaded:', this.user);
//       },
//       error: (error) => {
//         console.error('Error loading user profile:', error);
//         this.router.navigate(['/loginpage']);
//       }
//     });
//   }

//   ajouterMesure() {
//     this.router.navigate(['/add-energie']);
//   }

//   voirHistorique() {
//     this.router.navigate(['/historique-eau-page']);
//   }

//   ouvrirParametres() {
//     this.router.navigate(['/settings-page']);
//   }

//   logout() {
//     console.log('Déconnexion réussie !');
//     this.router.navigate(['/loginpage']);
//   }

//   setting() {
//     this.router.navigate(['/parametre']);
//   }

//   profile() {
//     this.router.navigate(['/profile-page']);
//   }

//   energie() {
//     this.router.navigate(['/energie-dashboard-page']);
//   }

//   water() {
//     this.router.navigate(['/water-dashboard-page']);
//   }

//   Tableau_de_bord() {
//     this.router.navigate(['/dashboard']);
//   }
// }
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonSplitPane, IonMenu, IonMenuButton, IonContent, IonHeader, IonTitle, IonToolbar, IonCardContent, IonButton, IonButtons, IonCard, IonCardHeader, IonCardTitle, IonIcon, IonList, IonItem, IonLabel, IonApp, IonFooter, IonRouterOutlet, IonTabs, IonTabBar, IonTabButton, IonAvatar } from '@ionic/angular/standalone';
import { NavController } from '@ionic/angular';
import { waterOutline, flashOutline, addCircleOutline, timeOutline, settingsOutline, leafOutline, bulbOutline, sunnyOutline, barChartOutline, personOutline, logOutOutline, personCircleOutline } from 'ionicons/icons';
import { addIcons } from 'ionicons';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AuthService } from '../services/auth.services';
import { ConsommationEauService } from '../services/ConsommationEauService'; // Import the water service
import { ConsommationEnergieService } from '../services/ConsommationEnergieService'; // Import the energy service

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
  standalone: true,
  imports: [
    HttpClientModule,
    IonAvatar,
    IonRouterOutlet,
    IonFooter,
    IonApp,
    IonMenu,
    IonMenuButton,
    IonLabel,
    IonItem,
    IonList,
    IonIcon,
    IonCardTitle,
    IonCardHeader,
    IonCard,
    IonButtons,
    IonCardContent,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    CommonModule,
    FormsModule,
    IonTabs,
    IonTabBar,
    IonTabButton,

  ],
  providers: [AuthService, ConsommationEauService, ConsommationEnergieService] // Add services to providers
})
export class DashboardPage implements OnInit {
  private apiUrl = 'http://localhost:8081/api/users';
  user: any = null;
  totalWaterConsumption: number = 0; // Property for total water consumption
  totalEnergyConsumption: number = 0; // Property for total energy consumption

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private authService: AuthService,
    private http: HttpClient,
    private consommationEauService: ConsommationEauService, // Inject water service
    private consommationEnergieService: ConsommationEnergieService // Inject energy service
  ) {
    addIcons({'waterOutline':waterOutline,'bulbOutline':bulbOutline,'flashOutline':flashOutline,'addCircleOutline':addCircleOutline,'timeOutline':timeOutline,'settingsOutline':settingsOutline,'leafOutline':leafOutline,'barChartOutline':barChartOutline,'personOutline':personOutline,'logOutOutline':logOutOutline,'sunnyOutline':sunnyOutline,'personCircleOutline':personCircleOutline});
  }

  ngOnInit(): void {
    console.log('Dashboard initialized');
    this.loadUserProfile(); // Load user profile
    this.loadTotalConsumptions(); // Load total consumptions
  }

  loadUserProfile() {
    const userId = this.authService.getCurrentUserId();
    if (!userId || isNaN(userId)) {
      console.error('Invalid user ID');
      this.router.navigate(['/loginpage']);
      return;
    }

    this.http.get(`${this.apiUrl}/profile/${userId}`).subscribe({
      next: (response: any) => {
        this.user = response;
        if (this.user.profileImage) {
          this.user.profileImage = `${this.apiUrl.replace('/api/users', '')}${this.user.profileImage}`;
        }
        console.log('User profile loaded:', this.user);
      },
      error: (error) => {
        console.error('Error loading user profile:', error);
        this.router.navigate(['/loginpage']);
      }
    });
  }

  // Method to load total water and energy consumption
  loadTotalConsumptions() {
    // Fetch total water consumption
    this.consommationEauService.getAllConsommations().subscribe({
      next: (entries) => {
        this.totalWaterConsumption = entries.reduce((total, entry) => total + entry.value, 0);
        console.log('Total water consumption:', this.totalWaterConsumption);
      },
      error: (error) => {
        console.error('Error fetching water consumption:', error);
      }
    });

    // Fetch total energy consumption
    this.consommationEnergieService.getAllConsommations().subscribe({
      next: (entries) => {
        this.totalEnergyConsumption = entries.reduce((total, entry) => total + entry.value, 0);
        console.log('Total energy consumption:', this.totalEnergyConsumption);
      },
      error: (error) => {
        console.error('Error fetching energy consumption:', error);
      }
    });
  }

  ajouterMesure() {
    this.router.navigate(['/add-energie']);
  }

  voirHistorique() {
    this.router.navigate(['/historique-energie-page']);
  }

  ouvrirParametres() {
    this.router.navigate(['/settings-page']);
  }

  logout() {
    console.log('Déconnexion réussie !');
    this.router.navigate(['/loginpage']);
  }

  setting() {
    this.router.navigate(['/settings-page']);
  }

  profile() {
    this.router.navigate(['/profile-page']);
  }

  energie() {
    this.router.navigate(['/energie-dashboard-page']);
  }

  water() {
    this.router.navigate(['/water-dashboard-page']);
  }

  Tableau_de_bord() {
    this.router.navigate(['/dashboard']);
  }
}