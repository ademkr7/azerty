import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule, ToastController } from '@ionic/angular';
import { ConsommationEnergieService,ConsommationEnergie } from '../services/ConsommationEnergieService';
import { AuthService } from '../services/auth.services';
import { HttpClientModule } from '@angular/common/http';
import { addIcons } from 'ionicons';
import { flashOutline } from 'ionicons/icons';
import { SettingsService } from '../services/SettingsService';
import { Router } from '@angular/router';
@Component({
  selector: 'app-historique-energie-page',
  templateUrl: './historique-energie-page.page.html',
  styleUrls: ['./historique-energie-page.page.scss'],
  standalone: true,
 imports: [
     IonicModule,
     CommonModule,
     HttpClientModule
   ],
   providers: [ConsommationEnergieService, AuthService,SettingsService]
 })
export class HistoriqueEnergiePagePage implements OnInit {

  consommations: ConsommationEnergie[] = [];
  isLoading = false;
  energyUnit: string = 'kWh'; // Default unit

  constructor(
    private consommationService: ConsommationEnergieService,
    private authService: AuthService,
    private settingsService: SettingsService,
    private toastController: ToastController,
    private router: Router,
  ) {
    addIcons({ 'flash-outline': flashOutline });
  }

  ngOnInit() {
    // Load energy unit from settings
    this.settingsService.getSettings().subscribe(settings => {
      this.energyUnit = settings.energyUnit || 'kWh';
      // Reload consumptions to apply unit conversion
      this.loadConsommations();
    });
  }

  loadConsommations() {
    this.isLoading = true;
    const token = this.authService.getToken();
    if (!token) {
      this.isLoading = false;
      this.presentToast('Veuillez vous connecter.', 'danger');
      this.authService.logout();
      return;
    }

    this.consommationService.getAllConsommations().subscribe({
      next: (data: ConsommationEnergie[]) => {
        this.consommations = data
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
          .map(consommation => ({
            ...consommation,
            value: this.energyUnit === 'W' ? consommation.value * 1000 : consommation.value
          }));
        this.isLoading = false;
      },
      error: (error) => {
        this.isLoading = false;
        let errorMessage = 'Erreur lors du chargement des données.';
        if (error.status === 403) {
          errorMessage = 'Accès refusé. Veuillez vous reconnecter.';
          this.authService.logout();
        } else if (error.status === 0) {
          errorMessage = 'Erreur de connexion au serveur.';
        }
        this.presentToast(errorMessage, 'danger');
        console.error('Erreur:', error);
      }
    });
  }

  refresh(event: CustomEvent<{ complete: () => void }>) {
    this.loadConsommations();
    setTimeout(() => {
      event.detail.complete();
    }, 500);
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      color,
      position: 'bottom'
    });
    await toast.present();
  }

  historiqueeau() {
    this.router.navigate(['/historique-eau-page']);
  }
  historiqueenergie() {
    this.router.navigate(['/historique-energie-page']);
  }
}