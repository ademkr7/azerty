import { Component } from '@angular/core';
import {IonList,IonItem,IonIcon,IonLabel,IonButton,IonContent } from '@ionic/angular/standalone';
import {RouterModule } from '@angular/router';
import { addIcons } from 'ionicons';
import { statsChartOutline } from 'ionicons/icons';
import { bulbOutline } from 'ionicons/icons';
import { trophyOutline } from 'ionicons/icons';
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [RouterModule,IonList,IonItem,IonIcon,IonLabel,IonButton, IonContent],
})
export class HomePage {
  constructor() {
    addIcons({
      'stats-chart-outline': statsChartOutline,
      'bulb-outline':bulbOutline,
      'trophy-outline':trophyOutline

    });
  }
}
