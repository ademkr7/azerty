import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FormBuilder, FormGroup ,ReactiveFormsModule} from '@angular/forms';
import { AuthService } from '../services/auth.services';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AlertController, LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';
import { IonHeader } from "@ionic/angular/standalone";
import { IonicModule } from '@ionic/angular';
import { HttpClientModule } from '@angular/common/http';
@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.page.html',
  styleUrls: ['./profile-page.page.scss'],
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, FormsModule,IonicModule,HttpClientModule],
  providers: [AuthService]
})
export class ProfilePagePage implements OnInit {

  private apiUrl = 'http://localhost:8081/api/users';
  profileForm: FormGroup;
  profileImage: string | null = null;
  selectedFile: File | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private http: HttpClient,
    private alertController: AlertController,
    private loadingController: LoadingController,
    private router: Router
  ) {
    this.profileForm = this.fb.group({
      id: [null],
      username: [''],
      email: [''],
      password: [''],
      phoneNumber: [''],
      address: [''],
      nombreOccupant: [null],
      typeLogement: ['']
    });
  }

  ngOnInit() {
    this.loadUserProfile();
  }

  async loadUserProfile() {
    const loading = await this.loadingController.create({ message: 'Chargement du profil...' });
    await loading.present();
  
    const userId = this.authService.getCurrentUserId();
    console.log('User ID from token:', userId);
  
    if (!userId || isNaN(userId)) {
      loading.dismiss();
      const token = this.authService.getToken();
      if (!token) {
        this.showErrorAlert('Aucun token trouvé. Veuillez vous connecter.');
        this.router.navigate(['/loginpage']);
      } else {
        this.showErrorAlert('ID utilisateur invalide. Veuillez réessayer.');
      }
      return;
    }
  
    this.http.get(`${this.apiUrl}/profile/${userId}`).subscribe({
      next: (response: any) => {
        console.log('Réponse du backend:', response);
        if (response && response.id) {
          this.profileForm.patchValue({ ...response, password: '' });
          this.profileImage = response.profileImage ? `${this.apiUrl.replace('/api/users', '')}${response.profileImage}` : null;
          console.log('Formulaire après patchValue:', this.profileForm.value);
          console.log('Profile image URL:', this.profileImage);
          loading.dismiss();
        } else {
          loading.dismiss();
          this.showErrorAlert('ID utilisateur non trouvé dans la réponse du serveur.');
          this.router.navigate(['/loginpage']);
        }
      },
      error: async (error) => {
        loading.dismiss();
        console.error('Erreur lors du chargement du profil:', error);
        await this.showErrorAlert('Impossible de charger le profil.');
      }
    });
  }
  async updateProfile() {
    const loading = await this.loadingController.create({ message: 'Mise à jour du profil...' });
    await loading.present();

    const userToUpdate = this.profileForm.value;
    console.log('Données à mettre à jour:', userToUpdate); // Debug : Vérifiez les données envoyées

    if (!userToUpdate.id) {
      loading.dismiss();
      this.showErrorAlert('ID utilisateur non défini. Impossible de mettre à jour.');
      return;
    }

    if (!userToUpdate.password) {
      delete userToUpdate.password; // Supprime le mot de passe s'il est vide
    }

    this.http.put(`${this.apiUrl}/${userToUpdate.id}`, userToUpdate).subscribe({
      next: async () => {
        loading.dismiss();
        await this.showSuccessAlert('Profil mis à jour avec succès');
      },
      error: async (error) => {
        loading.dismiss();
        console.error('Erreur lors de la mise à jour:', error); // Debug : Vérifiez l'erreur
        await this.showErrorAlert('Échec de la mise à jour du profil');
      }
    });
  }

  async deleteProfile() {
    const userId = this.profileForm.get('id')?.value;
    console.log('User ID to delete:', userId); // Debug : Vérifiez l'ID avant suppression

    if (!userId) {
      this.showErrorAlert('ID utilisateur non défini. Impossible de supprimer.');
      return;
    }

    const alert = await this.alertController.create({
      header: 'Confirmer la suppression',
      message: 'Voulez-vous vraiment supprimer votre compte ? Cette action est irréversible.',
      buttons: [
        {
          text: 'Annuler',
          role: 'cancel'
        },
        {
          text: 'Supprimer',
          handler: async () => {
            const loading = await this.loadingController.create({ message: 'Suppression en cours...' });
            await loading.present();

            this.http.delete(`${this.apiUrl}/${userId}`).subscribe({
              next: async () => {
                loading.dismiss();
                this.authService.logout();
                this.router.navigate(['/loginpage']);
                await this.showSuccessAlert('Compte supprimé avec succès');
              },
              error: async (error) => {
                loading.dismiss();
                console.error('Erreur lors de la suppression:', error); // Debug : Vérifiez l'erreur
                await this.showErrorAlert('Échec de la suppression du compte');
              }
            });
          }
        }
      ]
    });
    await alert.present();
  }


  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      // Validate file type in the frontend
      if (!this.selectedFile.type.startsWith('image/')) {
        this.showErrorAlert('Veuillez sélectionner une image (JPG, PNG, etc.)');
        this.selectedFile = null;
        return;
      }
      this.uploadImage();
    }
  }

  async uploadImage() {
    if (!this.selectedFile) return;

    const loading = await this.loadingController.create({ message: 'Téléchargement de l\'image...' });
    await loading.present();

    const token = this.authService.getToken();
    if (!token) {
      loading.dismiss();
      this.showErrorAlert('Aucun token trouvé. Veuillez vous connecter.');
      this.router.navigate(['/loginpage']);
      return;
    }

    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    const formData = new FormData();
    formData.append('file', this.selectedFile);

    this.http.post(`${this.apiUrl}/profile/image`, formData, { headers }).subscribe({
      next: (user: any) => {
        this.profileImage = user.profileImage ? `${this.apiUrl.replace('/api/users', '')}${user.profileImage}` : null;
        console.log('Updated profile image URL:', this.profileImage);
        loading.dismiss();
        this.showSuccessAlert('Image de profil mise à jour avec succès');
      },
      error: async (error) => {
        loading.dismiss();
        console.error('Erreur lors de l\'upload de l\'image:', error);
        await this.showErrorAlert('Échec de l\'upload de l\'image');
      }
    });
  }



























  private async showSuccessAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Succès',
      message,
      buttons: ['OK']
    });
    await alert.present();
  }

  private async showErrorAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Erreur',
      message,
      buttons: ['OK']
    });
    await alert.present();
  }
}