
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonSelectOption, IonContent, IonHeader, IonTitle, IonToolbar, IonCardContent, IonLabel, IonInput, IonItem, IonCard, IonButton, IonCardHeader, IonCardTitle, IonText, IonBackButton, IonButtons, IonList, IonSelect } from '@ionic/angular/standalone';
import { RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.services';
import { ToastController } from '@ionic/angular';
import { HttpClientModule } from '@angular/common/http';
import { Platform } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registerpage',
  templateUrl: './registerpage.page.html',
  styleUrls: ['./registerpage.page.scss'],
  standalone: true,
  imports: [IonSelectOption, HttpClientModule, ReactiveFormsModule, CommonModule, FormsModule, IonContent, IonHeader, IonTitle, IonToolbar, IonCardContent, IonLabel, IonInput, IonItem, IonCard, IonSelect, IonButton, IonText, IonBackButton, IonButtons,  RouterModule],
  providers: [AuthService]
})
export class RegisterPage {
  registerForm: FormGroup;

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private platform: Platform,
    private authService: AuthService,
    private toastController: ToastController
  ) {
    this.registerForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      userName: ['', [Validators.required, Validators.minLength(3)]],
      confirmPassword: ['', [Validators.required]],
      phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{8}$')]],
      address: ['', [Validators.required]],
      nombreOccupant: ['', [Validators.required, Validators.min(1)]],
      typeLogement: ['', [Validators.required]],
    });
  }

  async showToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      color,
      position: 'top'
    });
    await toast.present();
  }

  async onRegister() {
    if (this.registerForm.valid) {
      if (this.registerForm.value.password !== this.registerForm.value.confirmPassword) {
        this.showToast('Les mots de passe ne correspondent pas.', 'danger');
        return;
      }
  
      try {
        const response: { token: string } | undefined = await this.authService.register(
          this.registerForm.value.email,
          this.registerForm.value.password,
          this.registerForm.value.userName,
          this.registerForm.value.phoneNumber,
          this.registerForm.value.address,
          this.registerForm.value.nombreOccupant,
          this.registerForm.value.typeLogement
        ).toPromise();
  
        console.log('Réponse complète de register:', response); // Debug
        if (response && response.token) { // Vérification explicite de response
          this.showToast('Inscription réussie !', 'success');
          // Attendre un court instant pour s'assurer que le token est stocké
          await new Promise(resolve => setTimeout(resolve, 100));
          const token = this.authService.getToken();
          console.log('Token après inscription:', token); // Debug
          if (token) {
            this.router.navigate(['/dashboard']);
          } else {
            this.showToast('Token non stocké correctement. Veuillez vous connecter.', 'warning');
            this.router.navigate(['/loginpage']);
          }
        } else {
          this.showToast('Token non généré par le serveur ou réponse invalide. Veuillez vous connecter.', 'warning');
          this.router.navigate(['/loginpage']);
        }
      } catch (err) {
        console.error('Erreur lors de l’inscription :', err);
        this.showToast('Échec de l’inscription. Réessayez plus tard.', 'danger');
      }
    } else {
      this.showToast('Veuillez remplir tous les champs correctement.', 'warning');
    }
  }

  initializeApp() {
    this.platform.ready().then(() => {
      document.addEventListener('ionRouteDidChange', () => {
        const hiddenPages = document.querySelectorAll('.ion-page[aria-hidden="true"]');
        hiddenPages.forEach(page => {
          if (!page.classList.contains('ion-page-hidden')) {
            page.removeAttribute('aria-hidden');
          }
        });
      });
    });
  }
}