

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.services';

export interface ConsommationEau {
  id: number;
  value: number;
  prix: number;
  category: string;
  date: string;
  notes?: string;
  user?: { id: number };
}

@Injectable({
  providedIn: 'root'
})
export class ConsommationEauService {
  private apiUrl = 'http://localhost:8081/api/consommation-eau';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) { }

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  addConsommationEau(consommation: any): Observable<ConsommationEau> {
    if (!consommation.userId) {
      console.error('Attention: userId manquant dans les données de consommation!');
    }
    return this.http.post<ConsommationEau>(this.apiUrl, consommation, { headers: this.getHeaders() });
  }

  // Update other methods similarly if needed
  getAllConsommations(): Observable<ConsommationEau[]> {
    return this.http.get<ConsommationEau[]>(this.apiUrl, { headers: this.getHeaders() });
  }

  getConsommationById(id: number): Observable<ConsommationEau> {
    return this.http.get<ConsommationEau>(`${this.apiUrl}/${id}`, { headers: this.getHeaders() });
  }

  updateConsommationEau(id: number, consommation: any): Observable<ConsommationEau> {
    return this.http.put<ConsommationEau>(`${this.apiUrl}/${id}`, consommation, { headers: this.getHeaders() });
  }

  deleteConsommationEau(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`, { headers: this.getHeaders() });
  }
  getStats(period: string, startDate: string, endDate: string): Observable<any> {
    const params = { period, startDate, endDate };
    return this.http.get<any>(`${this.apiUrl}/stats`, { headers: this.getHeaders(), params });
  }
}