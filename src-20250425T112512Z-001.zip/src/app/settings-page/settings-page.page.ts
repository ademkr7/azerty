// import { Component, OnInit } from '@angular/core';
// import { IonicModule } from '@ionic/angular';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { SettingsService } from '../services/SettingsService';
// import { ToastController } from '@ionic/angular';
// import { AuthService } from '../services/auth.services';
// import {
//   IonHeader,
//   IonToolbar,
//   IonTitle,
//   IonButtons,
//   IonBackButton,
//   IonContent,
//   IonList,
//   IonItem,
//   IonLabel,
//   IonToggle,
//   IonSelect,
//   IonSelectOption,
//   IonInput,
//   IonButton
// } from '@ionic/angular/standalone';

// @Component({
//   selector: 'app-settings-page',
//   templateUrl: './settings-page.page.html',
//   styleUrls: ['./settings-page.page.scss'],
//   standalone: true,
//   imports: [
//     IonicModule,
//     CommonModule,
//     FormsModule
//   ],
//   providers: [SettingsService, AuthService]
// })
// export class SettingsPagePage implements OnInit {
//   settings: any = {
//     darkMode: false,
//     waterUnit: 'litres',
//     energyUnit: 'kWh',
//     waterThreshold: 100,
//     energyThreshold: 10
//   };

//   constructor(
//     private settingsService: SettingsService,
//     private toastController: ToastController
//   ) {}

//   ngOnInit() {
//     // Load settings from service and apply dark mode
//     this.settingsService.getSettings().subscribe(settings => {
//       this.settings = { ...settings };
//       // Apply dark mode on initialization
//       document.body.classList.toggle('dark', this.settings.darkMode);
//     });
//   }

//   toggleDarkMode() {
//     // Toggle the dark class on the body
//     this.settings.darkMode = !this.settings.darkMode;
//     document.body.classList.toggle('dark', this.settings.darkMode);
//     // Save settings to persist the change
//     this.saveSettings();
//   }

//   saveSettings() {
//     this.settingsService.saveSettings(this.settings);
//     this.presentToast('Paramètres enregistrés avec succès !', 'success');
//   }

//   async presentToast(message: string, color: string) {
//     const toast = await this.toastController.create({
//       message,
//       duration: 2000,
//       color,
//       position: 'bottom'
//     });
//     await toast.present();
//   }
// }
import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SettingsService,AppSettings } from '../services/SettingsService';
import { ToastController } from '@ionic/angular';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonBackButton,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonToggle,
  IonSelect,
  IonSelectOption,
  IonInput,
  IonButton
} from '@ionic/angular/standalone';

@Component({
  standalone: true,
  selector: 'app-settings-page',
  templateUrl: './settings-page.page.html',
  styleUrls: ['./settings-page.page.scss'],
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonBackButton,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    IonToggle,
    IonSelect,
    IonSelectOption,
    IonInput,
    IonButton
  ],
  providers: [SettingsService]
})

export class SettingsPagePage implements OnInit {
  settings: AppSettings = {
    darkMode: false,
    waterUnit: 'litres',
    energyUnit: 'kWh',
    waterThreshold: 100,
    energyThreshold: 10,
    notifications: {
      manualEntryReminders: true,
      overconsumptionAlerts: true,
      savingTips: true
    }
  };

  constructor(
    private settingsService: SettingsService,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    this.settingsService.getSettings().subscribe(settings => {
      this.settings = {
        ...this.settings,
        ...settings,
        notifications: {
          ...this.settings.notifications,
          ...settings?.notifications
        }
      };
      document.body.classList.toggle('dark', this.settings.darkMode);
    });
  }

  toggleDarkMode() {
    this.settings.darkMode = !this.settings.darkMode;
    document.body.classList.toggle('dark', this.settings.darkMode);
    this.saveSettings();
  }

  saveSettings() {
    this.settingsService.saveSettings(this.settings);
    this.presentToast('Paramètres enregistrés avec succès !', 'success');
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      color,
      position: 'bottom'
    });
    await toast.present();
  }
}